<?php
class contoh1 extends CI_Controller
{
    public function index()
    {
        echo "<h1>perkenalan</h1>";
        echo"nama saya muhamad ariffadli fauzan 
        saya tinggal di daerah jakarta selatan 
        olahraga yang saya sukai adalah renang";
    }
}
?>